﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
           

            Console.WriteLine("Digite três valores quaisquer e obtenha o maior na sua tela");
            Console.WriteLine("Digite o primeiro valor");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o terceiro valor");
            c = double.Parse(Console.ReadLine());


            //primeiro valor
            if (a > b)
            if (a > c)
            {
                Console.WriteLine("O maior valor digitado foi o primeiro");
            }
            if (a == b)
            if (a == c)
                {
                    Console.WriteLine("Os valores digitados são iguais");
                }
            //segundo valor
            if (b > a)
            if (b > c)
                {
                    Console.WriteLine("O maior valor digitado foi o segundo");
                }
            if (b == a)
            if (b == c)
                {
                    Console.WriteLine("Os valores digitados são iguais");
                }
            //terceiro valor
            if (c > a)
            if (c > b)
                {
                    Console.WriteLine("O maior valor digitado foi o terceiro");
                }
            if (c == a)
            if (c == b)
                {
                    Console.WriteLine("Os valores digitados são iguais");
                }
            //ultima comparação
            if (a > c) 
            if (b > c)
            if (a == b)       
                {
                    Console.WriteLine("O primeiro valor e o segundo são maiores e iguais");
                }
            if (b > a)
            if (c > a)
            if (b == c)
                {
                    Console.WriteLine("O segundo valor e o terceiro são maiores e iguais");
                }
            if (c > b)
            if (a > b)
            if (a == c)
                    {
                        Console.WriteLine("O primeiro valor e o terceiro são maiores e iguais");
                    }
            Console.Read();
        }   
    }
}
