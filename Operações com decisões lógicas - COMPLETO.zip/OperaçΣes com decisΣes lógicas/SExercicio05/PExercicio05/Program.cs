﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double resultado;
            double comparativo = 100;

            Console.WriteLine("Calcule a area de um retangulo a partir deste programa");
            Console.WriteLine("Digite o valor da area");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da base");
            b = double.Parse(Console.ReadLine());

            resultado = b * a;

            if (resultado >= comparativo)
            {
                Console.WriteLine("Terreno Grande");
            }  
            else
                if (resultado <= comparativo)
            {
                Console.WriteLine("Terreno Pequeno");

            }
            Console.ReadLine();
        }
    }
}
