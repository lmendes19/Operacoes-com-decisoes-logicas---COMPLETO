﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;
            double resultado;

            Console.WriteLine("Digite três valores");
            Console.WriteLine("Digite o primeiro valor");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o terceiro valor");
            c = double.Parse(Console.ReadLine());

            resultado = a + b + c;

            if (a != b)
            if (a != c)
            if (b != c)
            if (b != a)
            if (c != a)
            if (c != b)
            {
                    Console.WriteLine("Foi formado um triangulo escaleno");
            }
           if (a == b)
           if (b == a)
           if (c == a)
                    {
                        Console.WriteLine("Foi formado um triangulo equilatero");
                    }
            if (a != b)
            if (c == b)
                        {
                        Console.WriteLine("Foi formado um triangulo isosceles");
                        }
            else
                if (b != c)
                if (c == a)
                            {
                                Console.WriteLine("Foi formado um triangulo isosceles");
                            }
            Console.ReadLine();
        }
    }
}
