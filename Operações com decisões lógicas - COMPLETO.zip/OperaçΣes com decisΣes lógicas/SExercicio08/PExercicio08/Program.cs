﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double b;
            double c;

            Console.WriteLine("Verifique se tres valores quaisquer formam ou não um triangulo");
            Console.WriteLine("Digite o primeiro valor");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o segundo valor");
            b= double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o terceiro valor");
            c= double.Parse(Console.ReadLine());

            if (a <= 0 || b <= 0 || c <= 0) 
            {
                Console.WriteLine("Lados nulos, negativos ou não aceitos");
            }
            if (a == b && b == c)
            {
                Console.WriteLine("Foi formado um Triangulo equilatero");
            }
            else
                if (a == b || b == c || c == a)
            {
                Console.WriteLine("Foi formado um Triangulo isosceles");

            }
            else
                Console.WriteLine("Foi formado um Triangulo escaleno");
            Console.ReadLine();
        }
    }
}
