﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso;
            double altura;
            double resultado;
            double x;
            

            Console.WriteLine("Obtenha o valor ideal do seu imc");
            Console.WriteLine("Digite o valor do peso em kg");
            peso = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da altura da pessoa em metros");
            altura = double.Parse(Console.ReadLine());

            x = altura * altura;
            resultado = peso / x;
            //feminino
            if (resultado < 19)
            {
                Console.WriteLine("Caso o sexo escolhido seja o feminino, está abaixo do peso");
            }
            if (resultado >= 24)
            {
                Console.WriteLine("Caso o sexo escolhido seja o feminino, está acima do peso");
            }
            if (resultado >=19)
            if (resultado <= 24)
                {
                    Console.WriteLine("Caso o sexo escolhido seja o feminino, está no peso ideal");
                }
            //masculino
            if (resultado < 20)
            {
                Console.WriteLine("Caso o sexo escolhido seja o masculino, está abaixo do peso");
            }
            if (resultado >= 25)
            {
                Console.WriteLine("Caso o sexo escolhido seja o masculino, está acima do peso");
            }
            if (resultado >= 20)
           if (resultado <= 25)
                {
                    Console.WriteLine("Caso o sexo escolhido seja o masculino, está no peso ideal");
                }
            Console.ReadLine();


        }
    }
}
