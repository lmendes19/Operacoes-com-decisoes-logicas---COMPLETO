﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2; 
            double p3;

            Console.WriteLine("Digite o valor da p1 e obtenha o minimo de valor que deverá tirar na p2 para ser aprovado(a)");
            Console.WriteLine("Digite o valor da p1");
            p1 = double.Parse(Console.ReadLine());

            if (p1 >= 5) 
            {
                Console.WriteLine("Você devera tirar um valor maior ou igual a 5 ");
            }
            else
            if (p1 == 4) 
            {
                Console.WriteLine("Você devera tirar um valor maior ou igual a 6 ");
            }
            else
            if (p1 == 3) 
            {
                Console.WriteLine("Você devera tirar um valor maior ou igual a 6 ");
            }
            else
            if (p1 <= 2) 
            {
                Console.WriteLine("Você devera tirar um valor maior ou igual a 7 ");
            }
            Console.Read();

        }
    }
}
